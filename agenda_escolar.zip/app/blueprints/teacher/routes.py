from datetime import date
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from . import teacher_bp
from ...utils.decorators import teacher_required
from ...services.attendance_service import AttendanceService
from ...services.grade_service import GradeService
from ...services.analytics_service import AnalyticsService
from ...repositories.class_repository import ClassRepository
from ...repositories.user_repository import UserRepository
from ...repositories.assignment_repository import AssignmentRepository
from ...models.class_ import ClassSubject
from ...models.assignment import Assignment
from ...models.school_year import SchoolYear, GradePeriod
from ...utils.helpers import active_school_year
from ...extensions import db

att_service = AttendanceService()
grade_service = GradeService()
analytics_service = AnalyticsService()
class_repo = ClassRepository()
user_repo = UserRepository()
assignment_repo = AssignmentRepository()


@teacher_bp.route("/")
@login_required
@teacher_required
def dashboard():
    school_year = active_school_year()
    class_subjects = []
    stats = {"students": 0, "upcoming_assignments": 0, "at_risk": 0}
    cs_stats = {"students_per_class": {}, "avg_per_cs": {}, "last_att_per_cs": {}}
    upcoming_assignments = []
    if school_year:
        class_subjects = class_repo.get_teacher_class_subjects(
            current_user.id, school_year.id
        )
        stats = analytics_service.get_teacher_stats(current_user.id, school_year.id)
        cs_stats = analytics_service.get_teacher_class_subject_stats(current_user.id, school_year.id)
        upcoming_assignments = analytics_service.get_upcoming_assignments(current_user.id, school_year.id)
    today = date.today()
    return render_template(
        "teacher/dashboard.html",
        class_subjects=class_subjects,
        school_year=school_year,
        today=today,
        stats=stats,
        cs_stats=cs_stats,
        upcoming_assignments=upcoming_assignments,
    )


@teacher_bp.route("/classes/")
@login_required
@teacher_required
def class_list():
    school_year = active_school_year()
    classes = class_repo.get_teacher_classes(
        current_user.id, school_year.id if school_year else None
    )
    return render_template("teacher/classes/list.html", classes=classes, school_year=school_year)


@teacher_bp.route("/classes/<int:class_id>")
@login_required
@teacher_required
def class_detail(class_id):
    class_ = class_repo.get_by_id(class_id)
    if not class_:
        abort(404)
    school_year = active_school_year()
    # Verifica se o professor está associado a essa turma
    my_class_subjects = class_repo.get_teacher_class_subjects(
        current_user.id, school_year.id if school_year else None
    )
    my_cs_ids = {cs.class_id for cs in my_class_subjects}
    if class_id not in my_cs_ids and current_user.role != "director":
        abort(403)
    students = user_repo.get_students_by_class(class_id)
    subject_class_subjects = [cs for cs in my_class_subjects if cs.class_id == class_id]
    return render_template(
        "teacher/classes/detail.html",
        class_=class_,
        students=students,
        subject_class_subjects=subject_class_subjects,
        school_year=school_year,
    )


# ── Chamada ───────────────────────────────────────────────────────────────────

@teacher_bp.route("/attendance/<int:cs_id>")
@login_required
@teacher_required
def attendance_history(cs_id):
    cs = db.session.get(ClassSubject, cs_id)
    if not cs or (cs.teacher_id != current_user.id and current_user.role != "director"):
        abort(403)
    sessions = att_service.get_sessions_for_class_subject(cs_id)
    return render_template("teacher/attendance/history.html", cs=cs, sessions=sessions)


@teacher_bp.route("/attendance/<int:cs_id>/take", methods=["GET", "POST"])
@login_required
@teacher_required
def attendance_take(cs_id):
    cs = db.session.get(ClassSubject, cs_id)
    if not cs or (cs.teacher_id != current_user.id and current_user.role != "director"):
        abort(403)
    students = user_repo.get_students_by_class(cs.class_id)

    if request.method == "POST":
        session_date_str = request.form.get("date", str(date.today()))
        session_date = date.fromisoformat(session_date_str)
        lesson_number = int(request.form.get("lesson_number", 1))
        records = []
        for student in students:
            status = request.form.get(f"status_{student.id}", "absent")
            justification = request.form.get(f"justification_{student.id}")
            records.append({
                "student_id": student.id,
                "status": status,
                "justification": justification,
            })
        att_service.take_attendance(
            class_id=cs.class_id,
            class_subject_id=cs_id,
            teacher_id=current_user.id,
            session_date=session_date,
            records=records,
            lesson_number=lesson_number,
        )
        flash("Chamada salva com sucesso!", "success")
        return redirect(url_for("teacher.attendance_history", cs_id=cs_id))

    today = date.today()
    return render_template("teacher/attendance/take.html", cs=cs, students=students, today=today)


# ── Notas ─────────────────────────────────────────────────────────────────────

@teacher_bp.route("/grades/<int:cs_id>")
@login_required
@teacher_required
def grades_overview(cs_id):
    cs = db.session.get(ClassSubject, cs_id)
    if not cs or (cs.teacher_id != current_user.id and current_user.role != "director"):
        abort(403)
    students = user_repo.get_students_by_class(cs.class_id)
    periods = db.session.execute(
        db.select(GradePeriod)
        .where(GradePeriod.school_year_id == cs.school_year_id)
        .order_by(GradePeriod.order_index)
    ).scalars().all()

    # Monta grade de notas: {student_id: {period_id: {grade_type: score}}}
    from ...models.grade import Grade
    all_grades = db.session.execute(
        db.select(Grade).where(Grade.class_subject_id == cs_id)
    ).scalars().all()
    grade_map = {}
    for g in all_grades:
        grade_map.setdefault(g.student_id, {}).setdefault(g.grade_period_id, {})[g.grade_type] = float(g.score)

    return render_template(
        "teacher/grades/overview.html",
        cs=cs,
        students=students,
        periods=periods,
        grade_map=grade_map,
    )


@teacher_bp.route("/grades/save", methods=["POST"])
@login_required
@teacher_required
def grades_save():
    data = request.get_json()
    if not data:
        return {"error": "dados inválidos"}, 400
    entries = data.get("grades", [])
    try:
        grade_service.save_bulk_grades(entries)
        return {"status": "ok", "saved": len(entries)}
    except Exception as e:
        return {"error": str(e)}, 500


# ── Atividades ────────────────────────────────────────────────────────────────

@teacher_bp.route("/assignments/")
@login_required
@teacher_required
def assignment_list():
    school_year = active_school_year()
    my_cs = class_repo.get_teacher_class_subjects(
        current_user.id, school_year.id if school_year else None
    )
    cs_ids = [cs.id for cs in my_cs]
    assignments = []
    if cs_ids:
        assignments = db.session.execute(
            db.select(Assignment)
            .where(Assignment.class_subject_id.in_(cs_ids))
            .order_by(Assignment.due_date)
        ).scalars().all()
    return render_template("teacher/assignments/list.html", assignments=assignments)


@teacher_bp.route("/assignments/new", methods=["GET", "POST"])
@login_required
@teacher_required
def assignment_new():
    school_year = active_school_year()
    my_cs = class_repo.get_teacher_class_subjects(
        current_user.id, school_year.id if school_year else None
    )
    if request.method == "POST":
        from datetime import datetime
        due = request.form.get("due_date")
        a = Assignment(
            class_subject_id=int(request.form["class_subject_id"]),
            teacher_id=current_user.id,
            title=request.form["title"].strip(),
            description=request.form.get("description"),
            due_date=datetime.fromisoformat(due) if due else None,
            max_score=float(request.form.get("max_score", 10)),
            type=request.form.get("type", "homework"),
        )
        db.session.add(a)
        db.session.commit()
        flash("Atividade criada!", "success")
        return redirect(url_for("teacher.assignment_list"))
    return render_template("teacher/assignments/form.html", class_subjects=my_cs, action="new")


@teacher_bp.route("/assignments/<int:assignment_id>/edit", methods=["GET", "POST"])
@login_required
@teacher_required
def assignment_edit(assignment_id):
    a = db.session.get(Assignment, assignment_id)
    if not a or a.teacher_id != current_user.id:
        abort(403)
    school_year = active_school_year()
    my_cs = class_repo.get_teacher_class_subjects(
        current_user.id, school_year.id if school_year else None
    )
    if request.method == "POST":
        from datetime import datetime
        due = request.form.get("due_date")
        a.title = request.form["title"].strip()
        a.description = request.form.get("description")
        a.due_date = datetime.fromisoformat(due) if due else None
        a.max_score = float(request.form.get("max_score", 10))
        a.type = request.form.get("type", "homework")
        db.session.commit()
        flash("Atividade atualizada!", "success")
        return redirect(url_for("teacher.assignment_list"))
    return render_template("teacher/assignments/form.html", assignment=a, class_subjects=my_cs, action="edit")
