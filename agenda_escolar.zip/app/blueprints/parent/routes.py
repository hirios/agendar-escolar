from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from . import parent_bp
from ...utils.decorators import parent_required
from ...repositories.user_repository import UserRepository
from ...services.grade_service import GradeService
from ...services.attendance_service import AttendanceService
from ...models.message import Message
from ...utils.helpers import active_school_year
from ...extensions import db

user_repo = UserRepository()
grade_service = GradeService()
att_service = AttendanceService()


def _get_children():
    return user_repo.get_children_of_parent(current_user.id)


def _verify_child(student_id):
    children = _get_children()
    child = next((c for c in children if c.id == student_id), None)
    if not child:
        abort(403)
    return child


@parent_bp.route("/")
@login_required
@parent_required
def dashboard():
    children = _get_children()
    school_year = active_school_year()
    children_data = []
    for child in children:
        gpa = None
        att_summary = []
        if school_year:
            gpa = grade_service.get_student_gpa(child.id, school_year.id)
            att_summary = att_service.get_summary_for_student(child.id, school_year.id)
        children_data.append({"student": child, "gpa": gpa, "attendance": att_summary})
    return render_template("parent/dashboard.html", children_data=children_data, school_year=school_year)


@parent_bp.route("/child/<int:student_id>/grades")
@login_required
@parent_required
def child_grades(student_id):
    child = _verify_child(student_id)
    school_year = active_school_year()
    boletim = periods = None
    gpa = None
    if school_year:
        boletim, periods = grade_service.get_boletim(child.id, school_year.id)
        gpa = grade_service.get_student_gpa(child.id, school_year.id)
    return render_template(
        "parent/grades.html",
        student=child,
        boletim=boletim,
        periods=periods,
        gpa=gpa,
        school_year=school_year,
    )


@parent_bp.route("/child/<int:student_id>/attendance")
@login_required
@parent_required
def child_attendance(student_id):
    child = _verify_child(student_id)
    school_year = active_school_year()
    summary = []
    if school_year:
        summary = att_service.get_summary_for_student(child.id, school_year.id)
    return render_template("parent/attendance.html", student=child, summary=summary, school_year=school_year)


@parent_bp.route("/messages/")
@login_required
@parent_required
def messages():
    inbox = current_user.received_messages.order_by(Message.sent_at.desc()).limit(50).all()
    return render_template("parent/messages.html", inbox=inbox)


@parent_bp.route("/messages/send", methods=["POST"])
@login_required
@parent_required
def send_message():
    recipient_id = request.form.get("recipient_id", type=int)
    subject = request.form.get("subject", "").strip()
    body = request.form.get("body", "").strip()
    if not body or not recipient_id:
        flash("Mensagem ou destinatário inválido.", "error")
        return redirect(url_for("parent.messages"))
    recipient = user_repo.get_by_id(recipient_id)
    if not recipient:
        abort(404)
    msg = Message(
        sender_id=current_user.id,
        recipient_id=recipient_id,
        subject=subject or "Sem assunto",
        body=body,
    )
    db.session.add(msg)
    db.session.commit()
    flash("Mensagem enviada!", "success")
    return redirect(url_for("parent.messages"))
