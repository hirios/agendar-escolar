from flask import render_template
from flask_login import login_required, current_user
from . import student_bp
from ...utils.decorators import student_required
from ...services.grade_service import GradeService
from ...services.attendance_service import AttendanceService
from ...repositories.assignment_repository import AssignmentRepository
from ...models.schedule import Schedule
from ...models.class_ import ClassSubject, ClassStudent
from ...utils.helpers import active_school_year
from ...extensions import db

grade_service = GradeService()
att_service = AttendanceService()
assignment_repo = AssignmentRepository()


@student_bp.route("/")
@login_required
@student_required
def dashboard():
    school_year = active_school_year()
    gpa = None
    attendance_summary = []
    upcoming_assignments = []
    boletim = None
    periods = None

    if school_year:
        gpa = grade_service.get_student_gpa(current_user.id, school_year.id)
        attendance_summary = att_service.get_summary_for_student(current_user.id, school_year.id)
        upcoming_assignments = assignment_repo.get_for_student(current_user.id, school_year.id)[:5]
        boletim, periods = grade_service.get_boletim(current_user.id, school_year.id)

    return render_template(
        "student/dashboard.html",
        school_year=school_year,
        gpa=gpa,
        attendance_summary=attendance_summary,
        upcoming_assignments=upcoming_assignments,
        boletim=boletim,
        periods=periods,
    )


@student_bp.route("/grades/")
@login_required
@student_required
def grades():
    school_year = active_school_year()
    boletim = periods = None
    gpa = None
    if school_year:
        boletim, periods = grade_service.get_boletim(current_user.id, school_year.id)
        gpa = grade_service.get_student_gpa(current_user.id, school_year.id)
    return render_template(
        "student/grades.html",
        boletim=boletim,
        periods=periods,
        gpa=gpa,
        school_year=school_year,
    )


@student_bp.route("/attendance/")
@login_required
@student_required
def attendance():
    school_year = active_school_year()
    summary = []
    if school_year:
        summary = att_service.get_summary_for_student(current_user.id, school_year.id)
    return render_template("student/attendance.html", summary=summary, school_year=school_year)


@student_bp.route("/assignments/")
@login_required
@student_required
def assignments():
    school_year = active_school_year()
    all_assignments = []
    if school_year:
        all_assignments = assignment_repo.get_for_student(current_user.id, school_year.id)
    return render_template("student/assignments.html", assignments=all_assignments, school_year=school_year)


@student_bp.route("/schedule/")
@login_required
@student_required
def schedule():
    school_year = active_school_year()
    schedules = []
    if school_year:
        enrollment = db.session.execute(
            db.select(ClassStudent)
            .where(ClassStudent.student_id == current_user.id, ClassStudent.status == "active")
        ).scalars().all()
        class_ids = [e.class_id for e in enrollment]
        if class_ids:
            cs_ids = db.session.execute(
                db.select(ClassSubject.id)
                .where(ClassSubject.class_id.in_(class_ids), ClassSubject.school_year_id == school_year.id)
            ).scalars().all()
            if cs_ids:
                schedules = db.session.execute(
                    db.select(Schedule)
                    .where(Schedule.class_subject_id.in_(cs_ids))
                    .order_by(Schedule.day_of_week, Schedule.start_time)
                ).scalars().all()
    return render_template("student/schedule.html", schedules=schedules, school_year=school_year)
